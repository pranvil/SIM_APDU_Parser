
import re
from typing import List, Tuple
from core.models import Message
from core.utils import normalize_hex

APDU_RX0 = re.compile(r'^\s*APDU_rx\s+0:\s*([0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})*)\s*$')
APDU_TX0 = re.compile(r'^\s*APDU_tx\s+0:\s*([0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})*)\s*$')
APDU_RXN = re.compile(r'^\s*APDU_rx\s+(\d+):\s*([0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})*)\s*$')
APDU_TXN = re.compile(r'^\s*APDU_tx\s+(\d+):\s*([0-9A-Fa-f]{2}(?:\s+[0-9A-Fa-f]{2})*)\s*$')

def _is_lpa_to_esim(apdu_hex: str) -> bool:
    """检查是否为LPA=>eSIM消息"""
    if len(apdu_hex) < 8:  # 至少需要4字节头部
        return False
    cla = int(apdu_hex[0:2], 16)
    ins = int(apdu_hex[2:4], 16)
    return ((0x80 <= cla <= 0x83) or (0xC0 <= cla <= 0xCF)) and ins == 0xE2

def _parse_apdu_header(apdu_hex: str) -> Tuple[int, int, int, int]:
    """解析APDU头部：CLA, INS, P1, P2"""
    if len(apdu_hex) < 8:
        return 0, 0, 0, 0
    cla = int(apdu_hex[0:2], 16)
    ins = int(apdu_hex[2:4], 16)
    p1 = int(apdu_hex[4:6], 16)
    p2 = int(apdu_hex[6:8], 16)
    return cla, ins, p1, p2

def _extract_esim_tag_and_length(apdu_hex: str) -> Tuple[str, int]:
    """从APDU数据中提取eSIM TAG和长度"""
    if len(apdu_hex) < 10:  # 至少需要5字节头部
        return "", 0
    
    # 跳过5字节APDU头部
    data_start = 10
    if len(apdu_hex) < data_start + 4:
        return "", 0
    
    # 提取TAG（1或2字节）
    tag = apdu_hex[data_start:data_start+2]
    if tag in ("9F", "5F", "7F", "BF") and len(apdu_hex) >= data_start + 4:
        tag = apdu_hex[data_start:data_start+4]
        length_start = data_start + 4
    else:
        length_start = data_start + 2
    
    # 提取长度
    if length_start + 2 > len(apdu_hex):
        return tag, 0
    
    length_hex = apdu_hex[length_start:length_start+2]
    length = int(length_hex, 16)
    
    return tag, length

def _collect_one(lines: List[str], i: int, head_re0, cont_re):
    m = head_re0.match(lines[i])
    if not m: return None, i
    parts = [m.group(1)]; i += 1
    while i < len(lines):
        n = cont_re.match(lines[i])
        if n:
            parts.append(n.group(2)); i += 1
        else:
            break
    return ' '.join(parts), i

class MTKExtractor:
    def extract_from_text(self, text: str) -> List[Message]:
        """Preserve chronological order of APDU_tx/APDU_rx groups with LPA=>eSIM reassembly."""
        lines = text.splitlines()
        msgs: List[Message] = []
        i = 0
        processed_indices = set()  # 记录已处理的行索引
        
        while i < len(lines):
            # 跳过已处理的行
            if i in processed_indices:
                i += 1
                continue
            
            line = lines[i].strip()
            
            # 处理TX消息
            if line.startswith("APDU_tx"):
                # 先收集当前TX段的所有行
                r = _collect_one(lines, i, APDU_TX0, APDU_TXN)
                if r[0] is not None:
                    raw, next_i = r
                    s = normalize_hex(raw)
                    if s and _is_lpa_to_esim(s):
                        # 尝试重组多段LPA=>eSIM消息
                        reassembled, processed_lines = self._try_reassemble_lpa_esim(lines, i, s)
                        if reassembled and len(processed_lines) > 1:
                            msgs.append(Message(raw=reassembled, direction="tx", meta={"source":"mtk", "reassembled":True}))
                            # 标记所有已处理的行
                            for line_idx in processed_lines:
                                processed_indices.add(line_idx)
                            # 跳到下一个未处理的行
                            i = max(processed_lines) + 1
                            continue
                        else:
                            # 单段消息
                            msgs.append(Message(raw=s, direction="tx", meta={"source":"mtk"}))
                            i = next_i
                            continue
                    else:
                        # 非LPA=>eSIM消息
                        msgs.append(Message(raw=s, direction="tx", meta={"source":"mtk"}))
                        i = next_i
                        continue
            
            # 处理RX消息
            elif line.startswith("APDU_rx"):
                r = _collect_one(lines, i, APDU_RX0, APDU_RXN)
                if r[0] is not None:
                    raw, i = r
                    s = normalize_hex(raw)
                    if s:
                        msgs.append(Message(raw=s, direction="rx", meta={"source":"mtk"}))
                    continue
            
            i += 1
        
        return msgs
    
    def _try_reassemble_lpa_esim(self, lines: List[str], start_idx: int, first_apdu: str) -> Tuple[str, List[int]]:
        """尝试重组LPA=>eSIM的多段消息，返回重组后的消息和处理的行索引"""
        cla, ins, p1, p2 = _parse_apdu_header(first_apdu)
        tag, expected_length = _extract_esim_tag_and_length(first_apdu)
        
        # 只有第一段包含TAG，其他段只包含数据
        if not tag or expected_length == 0:
            return first_apdu, [start_idx]  # 无法解析，返回原始数据
        
        # 收集所有相关的TX段
        segments = [first_apdu]
        processed_indices = [start_idx]  # 记录处理的行索引
        current_idx = start_idx + 1
        
        while current_idx < len(lines):
            line = lines[current_idx].strip()
            if not line.startswith("APDU_tx"):
                break
            
            # 收集当前TX段的所有行
            segment_lines = []
            segment_start_idx = current_idx
            
            # 收集连续的TX行
            while current_idx < len(lines):
                line = lines[current_idx].strip()
                if not line.startswith("APDU_tx"):
                    break
                
                tx_match = APDU_TX0.match(line) or APDU_TXN.match(line)
                if not tx_match:
                    break
                
                segment_lines.append(tx_match.group(1))
                current_idx += 1
            
            # 合并当前段的所有行
            if segment_lines:
                current_apdu = normalize_hex(' '.join(segment_lines))
                
                # 检查是否为同一消息的下一段
                curr_cla, curr_ins, curr_p1, curr_p2 = _parse_apdu_header(current_apdu)
                if (curr_cla == cla and curr_ins == ins and 
                    curr_p1 in (0x11, 0x91)):
                    segments.append(current_apdu)
                    # 记录这个段涉及的所有行索引
                    for idx in range(segment_start_idx, current_idx):
                        processed_indices.append(idx)
                else:
                    # 不是同一消息的段，回退索引
                    current_idx = segment_start_idx
                    break
            else:
                break
        
        # 重组消息
        if len(segments) > 1:
            reassembled = self._reassemble_apdu_segments(segments, tag, expected_length)
            return reassembled, processed_indices
        
        return first_apdu, [start_idx]
    
    def _reassemble_apdu_segments(self, segments: List[str], tag: str, expected_length: int) -> str:
        """重组APDU段"""
        if not segments:
            return ""
        
        # 使用第一段的头部
        header = segments[0][:10]  # 5字节头部
        
        # 收集所有数据段
        all_data = ""
        for segment in segments:
            if len(segment) > 10:
                all_data += segment[10:]  # 跳过头部
        
        # 计算实际长度
        actual_length = len(all_data) // 2  # 转换为字节数
        
        # 构建重组后的APDU
        if actual_length >= 255:
            # 使用扩展长度格式
            if actual_length <= 0xFF:
                length_field = f"{actual_length:02X}"
            elif actual_length <= 0xFFFF:
                length_field = f"81{actual_length:04X}"
            else:
                length_field = f"82{actual_length:06X}"
        else:
            length_field = f"{actual_length:02X}"
        
        reassembled = header + tag + length_field + all_data
        
        return reassembled
