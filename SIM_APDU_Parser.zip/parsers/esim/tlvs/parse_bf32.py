from core.models import MsgType, ParseNode
from core.registry import register
from core.tlv import parse_ber_tlvs
from core.utils import parse_iccid

@register(MsgType.ESIM, "BF32")
class BF32Parser:
    """DisableProfile - 禁用配置文件"""
    def build(self, payload_hex: str, direction: str) -> ParseNode:
        if direction == "LPA=>ESIM":
            return self._parse_request(payload_hex)
        else:
            return self._parse_response(payload_hex)
    
    def _parse_request(self, payload_hex: str) -> ParseNode:
        """解析DisableProfileRequest"""
        root = ParseNode(name="BF32: DisableProfileRequest")
        tlvs = parse_ber_tlvs(payload_hex)
        
        for t in tlvs:
            if t.tag == "4F":  # isdpAid
                root.children.append(ParseNode(name="profileIdentifier.isdpAid", value=t.value_hex))
            elif t.tag == "5A":  # iccid
                root.children.append(ParseNode(
                    name="profileIdentifier.iccid", 
                    value=parse_iccid(t.value_hex)
                ))
            elif t.tag == "01":  # BOOLEAN refreshFlag
                refresh_flag = t.value_hex == "FF"  # ASN.1 BOOLEAN: FF=True, 00=False
                root.children.append(ParseNode(
                    name="refreshFlag", 
                    value="True" if refresh_flag else "False",
                    hint=f"BOOLEAN: {t.value_hex}"
                ))
            else:
                root.children.append(ParseNode(
                    name=f"Unknown TLV {t.tag}", 
                    value=f"len={t.length}", 
                    hint=t.value_hex[:120]
                ))
        
        return root
    
    def _parse_response(self, payload_hex: str) -> ParseNode:
        """解析DisableProfileResponse"""
        root = ParseNode(name="BF32: DisableProfileResponse")
        tlvs = parse_ber_tlvs(payload_hex)
        
        for t in tlvs:
            if t.tag == "02":  # INTEGER disableResult
                result_code = int(t.value_hex or "0", 16)
                result_map = {
                    0: "ok",
                    1: "iccidOrAidNotFound", 
                    2: "profileNotInEnabledState",
                    3: "disallowedByPolicy",
                    5: "catBusy",
                    7: "commandError",
                    10: "disallowedForRpm",
                    127: "undefinedError"
                }
                result_name = result_map.get(result_code, f"Unknown({result_code})")
                root.children.append(ParseNode(
                    name="disableResult", 
                    value=f"{result_name}({result_code})",
                    hint=f"INTEGER: {t.value_hex}"
                ))
            else:
                root.children.append(ParseNode(
                    name=f"Unknown TLV {t.tag}", 
                    value=f"len={t.length}", 
                    hint=t.value_hex[:120]
                ))
        
        return root
