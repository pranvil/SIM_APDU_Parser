
from typing import Optional
from parsers import get_parser

def parse_esim_detail(tag: str, raw_hex: str) -> str:
    """
    Dispatch to the eSIM BFxx parser if available.
    Returns a human-readable multiline string.
    """
    if not tag:
        return "（暂无解析器）\n" + raw_hex

    parser = get_parser(tag.lower())  # expects like 'bf22'
    if parser is None:
        return "（暂无解析器）\n" + raw_hex

    try:
        return parser(raw_hex.strip())
    except Exception as e:
        return f"解析 {tag} 时出错: {e}\n\nRAW:\n{raw_hex}"
