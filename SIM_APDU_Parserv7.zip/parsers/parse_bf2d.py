from utils import parse_iccid,hex_to_utf8

def parse_bf2d(apdu_data):
    output = "ProfileInfo（BF2D）\n"
    e3_index = apdu_data.find("E3")
    length = len(apdu_data[e3_index:])
    index = e3_index  # Start from e3_index
    profile_id = 1
    while index < length:
        # Check for "E3" in the current position
        if apdu_data[index:index+2] == "E3":
            output += f"\t==== profile: {profile_id} ====\n"
            e3_length = int(apdu_data[index+2:index+4], 16)
            # Extract the e3_data to be parsed
            e3_data = apdu_data[index+4:index+4+e3_length*2]
            output += profileInfoList_parse(e3_data, e3_length * 2)
            index += 2  # Move past "E3"
            index += e3_length * 2  # Move past the length of the E3 block
            profile_id += 1
        else:
            index += 2  # Increment index to continue

    if output:
        return output
    else:
        return "BF22 解析未成功"

def profileInfoList_parse(apdu_data, length):
    output = ""
    index = 0
    while index < length:
        tag = apdu_data[index:index+2]
        if tag == "9F" or tag == "BF":
            tag = apdu_data[index:index+4]
            index += 4  # skip tag
            length_byte = int(apdu_data[index:index+2], 16)
        else:
            index += 2  # skip tag
            length_byte = int(apdu_data[index:index+2], 16)
        index += 2  # skip length
        value = apdu_data[index:index + (length_byte * 2)]
        index += length_byte * 2

        if tag == "5A":
            iccid = parse_iccid(value)
            output += f"\ticcid：{iccid}\n"
            
        elif tag == "4F":
            output += f"\tSD-P AID：{value}\n"
        elif tag == "9F70":
            if value == "00":
                output += f"\tProfile state：Disabled\n"
            elif value == "01":
                output += f"\tProfile state：Enabled\n"
            else:
                output += f"\tProfile state：Unknown\n"
        elif tag == "90":
            profile_nickname = hex_to_utf8(value)
            output += f"\tProfile Nickname：{profile_nickname}\n"
        elif tag == "91":
            service_provider_name = hex_to_utf8(value)
            output += f"\tService provider name：{service_provider_name}\n"
        elif tag == "92":
            profile_name = hex_to_utf8(value)
            output += f"\tProfile name：{profile_name}\n"
        elif tag == "93":
            output += f"\tIcon type：{value}\n"
        elif tag == "94":
            output += f"\tIcon: {value}\n"
        elif tag == "95":
            if value == "00":
                output += f"\tProfile Class：test\n"
            elif value == "01":
                output += f"\tProfile Class：provisioning\n"
            elif value == "02":
                output += f"\tProfile Class：operational\n"
            else:
                output += f"\tProfile Class：Unknown\n"
        elif tag == "B6":
            output += f"\tNotification Configuration Info：{value}\n"
        elif tag == "B7":
            output += f"\tProfile Owner：{value}\n"
        elif tag == "B8":
            output += f"\tSM-DP+ proprietary data：{value}\n"
        elif tag == "99":
            output += f"\tProfile Policy Rules：{value}\n"
        elif tag == "BF22":
            output += f"\tService Specific Data stored in eUICC：{value}\n"
        elif tag == "BA":
            output += f"\tRPM Configuration：{value}\n"
        elif tag == "9B":
            hri_server_address = hex_to_utf8(value)
            output += f"\tHRI Server address：{hri_server_address}\n"
        elif tag == "BC":
            output += f"\tLPR Configuration：{value}\n"
        elif tag == "BD":
            output += f"\tEnterprise Configuration：{value}\n"
        elif tag == "9F1F":
            output += f"\tService Description：{value}\n"
        elif tag == "BF20":
            output += f"\tDevice Change configuration：{value}\n"
        elif tag == "9F24":
            output += f"\tEnabled on eSIM Port：{value}\n"
        elif tag == "9F25":
            output += f"\tProfile Size：{value}\n"
        else:
            output += f"Unknown Tag {tag}: {value}\n"

    return output
